const AlertInfo = {
    message: '',
    type: '',
    loading: false
}

export default AlertInfo;