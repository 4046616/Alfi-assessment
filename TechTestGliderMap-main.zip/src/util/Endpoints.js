const Endpoints = {
  STOPS: 'https://hidden-refuge-13674.herokuapp.com/https://belfast-glider-api-server.herokuapp.com/list',
  STOP_INFO: 'https://hidden-refuge-13674.herokuapp.com/https://belfast-glider-api-server.herokuapp.com/stop'
}

export default Endpoints;
